﻿namespace Sudoku
{
    partial class gameWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.helpButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pauseButton = new System.Windows.Forms.Button();
            this.field1 = new System.Windows.Forms.Button();
            this.field2 = new System.Windows.Forms.Button();
            this.field3 = new System.Windows.Forms.Button();
            this.field4 = new System.Windows.Forms.Button();
            this.field5 = new System.Windows.Forms.Button();
            this.field6 = new System.Windows.Forms.Button();
            this.field7 = new System.Windows.Forms.Button();
            this.field8 = new System.Windows.Forms.Button();
            this.field9 = new System.Windows.Forms.Button();
            this.field10 = new System.Windows.Forms.Button();
            this.field11 = new System.Windows.Forms.Button();
            this.field13 = new System.Windows.Forms.Button();
            this.field12 = new System.Windows.Forms.Button();
            this.field16 = new System.Windows.Forms.Button();
            this.field14 = new System.Windows.Forms.Button();
            this.field15 = new System.Windows.Forms.Button();
            this.field17 = new System.Windows.Forms.Button();
            this.field18 = new System.Windows.Forms.Button();
            this.field19 = new System.Windows.Forms.Button();
            this.field20 = new System.Windows.Forms.Button();
            this.field22 = new System.Windows.Forms.Button();
            this.field21 = new System.Windows.Forms.Button();
            this.field31 = new System.Windows.Forms.Button();
            this.field25 = new System.Windows.Forms.Button();
            this.field23 = new System.Windows.Forms.Button();
            this.field34 = new System.Windows.Forms.Button();
            this.field24 = new System.Windows.Forms.Button();
            this.field32 = new System.Windows.Forms.Button();
            this.field26 = new System.Windows.Forms.Button();
            this.field33 = new System.Windows.Forms.Button();
            this.field35 = new System.Windows.Forms.Button();
            this.field27 = new System.Windows.Forms.Button();
            this.field36 = new System.Windows.Forms.Button();
            this.field28 = new System.Windows.Forms.Button();
            this.field29 = new System.Windows.Forms.Button();
            this.field30 = new System.Windows.Forms.Button();
            this.field46 = new System.Windows.Forms.Button();
            this.field37 = new System.Windows.Forms.Button();
            this.field47 = new System.Windows.Forms.Button();
            this.field38 = new System.Windows.Forms.Button();
            this.field49 = new System.Windows.Forms.Button();
            this.field40 = new System.Windows.Forms.Button();
            this.field48 = new System.Windows.Forms.Button();
            this.field39 = new System.Windows.Forms.Button();
            this.field52 = new System.Windows.Forms.Button();
            this.field43 = new System.Windows.Forms.Button();
            this.field50 = new System.Windows.Forms.Button();
            this.field41 = new System.Windows.Forms.Button();
            this.field51 = new System.Windows.Forms.Button();
            this.field42 = new System.Windows.Forms.Button();
            this.field53 = new System.Windows.Forms.Button();
            this.field44 = new System.Windows.Forms.Button();
            this.field45 = new System.Windows.Forms.Button();
            this.field54 = new System.Windows.Forms.Button();
            this.field73 = new System.Windows.Forms.Button();
            this.field64 = new System.Windows.Forms.Button();
            this.field74 = new System.Windows.Forms.Button();
            this.field65 = new System.Windows.Forms.Button();
            this.field76 = new System.Windows.Forms.Button();
            this.field67 = new System.Windows.Forms.Button();
            this.field75 = new System.Windows.Forms.Button();
            this.field58 = new System.Windows.Forms.Button();
            this.field55 = new System.Windows.Forms.Button();
            this.field66 = new System.Windows.Forms.Button();
            this.field79 = new System.Windows.Forms.Button();
            this.field70 = new System.Windows.Forms.Button();
            this.field77 = new System.Windows.Forms.Button();
            this.field61 = new System.Windows.Forms.Button();
            this.field68 = new System.Windows.Forms.Button();
            this.field78 = new System.Windows.Forms.Button();
            this.field59 = new System.Windows.Forms.Button();
            this.field56 = new System.Windows.Forms.Button();
            this.field69 = new System.Windows.Forms.Button();
            this.field80 = new System.Windows.Forms.Button();
            this.field71 = new System.Windows.Forms.Button();
            this.field60 = new System.Windows.Forms.Button();
            this.field57 = new System.Windows.Forms.Button();
            this.field62 = new System.Windows.Forms.Button();
            this.field72 = new System.Windows.Forms.Button();
            this.field81 = new System.Windows.Forms.Button();
            this.field63 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.currentTime = new System.Windows.Forms.Label();
            this.hideBoard = new System.Windows.Forms.PictureBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.hideBoard)).BeginInit();
            this.SuspendLayout();
            // 
            // helpButton
            // 
            this.helpButton.ForeColor = System.Drawing.Color.Red;
            this.helpButton.Location = new System.Drawing.Point(606, 358);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(130, 50);
            this.helpButton.TabIndex = 1;
            this.helpButton.Text = "I need help";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Help;
            this.button1.ForeColor = System.Drawing.Color.Green;
            this.button1.Location = new System.Drawing.Point(606, 240);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 112);
            this.button1.TabIndex = 2;
            this.button1.Text = "Progress check";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pauseButton
            // 
            this.pauseButton.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pauseButton.ForeColor = System.Drawing.Color.MidnightBlue;
            this.pauseButton.Location = new System.Drawing.Point(606, 9);
            this.pauseButton.Name = "pauseButton";
            this.pauseButton.Size = new System.Drawing.Size(130, 50);
            this.pauseButton.TabIndex = 3;
            this.pauseButton.Text = "Pause";
            this.pauseButton.UseVisualStyleBackColor = true;
            this.pauseButton.Click += new System.EventHandler(this.pauseButton_Click);
            // 
            // field1
            // 
            this.field1.BackColor = System.Drawing.Color.Transparent;
            this.field1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field1.Location = new System.Drawing.Point(2, 2);
            this.field1.Name = "field1";
            this.field1.Size = new System.Drawing.Size(65, 65);
            this.field1.TabIndex = 4;
            this.field1.UseVisualStyleBackColor = false;
            // 
            // field2
            // 
            this.field2.BackColor = System.Drawing.Color.Transparent;
            this.field2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field2.Location = new System.Drawing.Point(68, 2);
            this.field2.Name = "field2";
            this.field2.Size = new System.Drawing.Size(65, 65);
            this.field2.TabIndex = 4;
            this.field2.UseVisualStyleBackColor = false;
            // 
            // field3
            // 
            this.field3.BackColor = System.Drawing.Color.Transparent;
            this.field3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field3.Location = new System.Drawing.Point(134, 2);
            this.field3.Name = "field3";
            this.field3.Size = new System.Drawing.Size(65, 65);
            this.field3.TabIndex = 4;
            this.field3.UseVisualStyleBackColor = false;
            // 
            // field4
            // 
            this.field4.BackColor = System.Drawing.Color.Transparent;
            this.field4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field4.Location = new System.Drawing.Point(202, 3);
            this.field4.Name = "field4";
            this.field4.Size = new System.Drawing.Size(65, 65);
            this.field4.TabIndex = 4;
            this.field4.UseVisualStyleBackColor = false;
            // 
            // field5
            // 
            this.field5.BackColor = System.Drawing.Color.Transparent;
            this.field5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field5.Location = new System.Drawing.Point(268, 3);
            this.field5.Name = "field5";
            this.field5.Size = new System.Drawing.Size(65, 65);
            this.field5.TabIndex = 4;
            this.field5.UseVisualStyleBackColor = false;
            // 
            // field6
            // 
            this.field6.BackColor = System.Drawing.Color.Transparent;
            this.field6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field6.Location = new System.Drawing.Point(334, 3);
            this.field6.Name = "field6";
            this.field6.Size = new System.Drawing.Size(65, 65);
            this.field6.TabIndex = 4;
            this.field6.UseVisualStyleBackColor = false;
            // 
            // field7
            // 
            this.field7.BackColor = System.Drawing.Color.Transparent;
            this.field7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field7.Location = new System.Drawing.Point(402, 3);
            this.field7.Name = "field7";
            this.field7.Size = new System.Drawing.Size(65, 65);
            this.field7.TabIndex = 4;
            this.field7.UseVisualStyleBackColor = false;
            // 
            // field8
            // 
            this.field8.BackColor = System.Drawing.Color.Transparent;
            this.field8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field8.Location = new System.Drawing.Point(466, 3);
            this.field8.Name = "field8";
            this.field8.Size = new System.Drawing.Size(69, 65);
            this.field8.TabIndex = 4;
            this.field8.UseVisualStyleBackColor = false;
            // 
            // field9
            // 
            this.field9.BackColor = System.Drawing.Color.Transparent;
            this.field9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field9.Location = new System.Drawing.Point(536, 3);
            this.field9.Name = "field9";
            this.field9.Size = new System.Drawing.Size(64, 65);
            this.field9.TabIndex = 4;
            this.field9.UseVisualStyleBackColor = false;
            // 
            // field10
            // 
            this.field10.BackColor = System.Drawing.Color.Transparent;
            this.field10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field10.Location = new System.Drawing.Point(2, 67);
            this.field10.Name = "field10";
            this.field10.Size = new System.Drawing.Size(65, 66);
            this.field10.TabIndex = 4;
            this.field10.UseVisualStyleBackColor = false;
            // 
            // field11
            // 
            this.field11.BackColor = System.Drawing.Color.Transparent;
            this.field11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field11.Location = new System.Drawing.Point(68, 67);
            this.field11.Name = "field11";
            this.field11.Size = new System.Drawing.Size(65, 66);
            this.field11.TabIndex = 4;
            this.field11.UseVisualStyleBackColor = false;
            // 
            // field13
            // 
            this.field13.BackColor = System.Drawing.Color.Transparent;
            this.field13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field13.Location = new System.Drawing.Point(202, 68);
            this.field13.Name = "field13";
            this.field13.Size = new System.Drawing.Size(65, 65);
            this.field13.TabIndex = 4;
            this.field13.UseVisualStyleBackColor = false;
            // 
            // field12
            // 
            this.field12.BackColor = System.Drawing.Color.Transparent;
            this.field12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field12.Location = new System.Drawing.Point(134, 67);
            this.field12.Name = "field12";
            this.field12.Size = new System.Drawing.Size(65, 66);
            this.field12.TabIndex = 4;
            this.field12.UseVisualStyleBackColor = false;
            // 
            // field16
            // 
            this.field16.BackColor = System.Drawing.Color.Transparent;
            this.field16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field16.Location = new System.Drawing.Point(402, 68);
            this.field16.Name = "field16";
            this.field16.Size = new System.Drawing.Size(65, 65);
            this.field16.TabIndex = 4;
            this.field16.UseVisualStyleBackColor = false;
            // 
            // field14
            // 
            this.field14.BackColor = System.Drawing.Color.Transparent;
            this.field14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field14.Location = new System.Drawing.Point(268, 68);
            this.field14.Name = "field14";
            this.field14.Size = new System.Drawing.Size(65, 65);
            this.field14.TabIndex = 4;
            this.field14.UseVisualStyleBackColor = false;
            // 
            // field15
            // 
            this.field15.BackColor = System.Drawing.Color.Transparent;
            this.field15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field15.Location = new System.Drawing.Point(334, 68);
            this.field15.Name = "field15";
            this.field15.Size = new System.Drawing.Size(65, 65);
            this.field15.TabIndex = 4;
            this.field15.UseVisualStyleBackColor = false;
            // 
            // field17
            // 
            this.field17.BackColor = System.Drawing.Color.Transparent;
            this.field17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field17.Location = new System.Drawing.Point(466, 68);
            this.field17.Name = "field17";
            this.field17.Size = new System.Drawing.Size(69, 65);
            this.field17.TabIndex = 4;
            this.field17.UseVisualStyleBackColor = false;
            // 
            // field18
            // 
            this.field18.BackColor = System.Drawing.Color.Transparent;
            this.field18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field18.Location = new System.Drawing.Point(536, 68);
            this.field18.Name = "field18";
            this.field18.Size = new System.Drawing.Size(64, 65);
            this.field18.TabIndex = 4;
            this.field18.UseVisualStyleBackColor = false;
            // 
            // field19
            // 
            this.field19.BackColor = System.Drawing.Color.Transparent;
            this.field19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field19.Location = new System.Drawing.Point(2, 133);
            this.field19.Name = "field19";
            this.field19.Size = new System.Drawing.Size(65, 66);
            this.field19.TabIndex = 4;
            this.field19.UseVisualStyleBackColor = false;
            // 
            // field20
            // 
            this.field20.BackColor = System.Drawing.Color.Transparent;
            this.field20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field20.Location = new System.Drawing.Point(68, 133);
            this.field20.Name = "field20";
            this.field20.Size = new System.Drawing.Size(65, 66);
            this.field20.TabIndex = 4;
            this.field20.UseVisualStyleBackColor = false;
            // 
            // field22
            // 
            this.field22.BackColor = System.Drawing.Color.Transparent;
            this.field22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field22.Location = new System.Drawing.Point(202, 134);
            this.field22.Name = "field22";
            this.field22.Size = new System.Drawing.Size(65, 65);
            this.field22.TabIndex = 4;
            this.field22.UseVisualStyleBackColor = false;
            // 
            // field21
            // 
            this.field21.BackColor = System.Drawing.Color.Transparent;
            this.field21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field21.Location = new System.Drawing.Point(134, 133);
            this.field21.Name = "field21";
            this.field21.Size = new System.Drawing.Size(65, 66);
            this.field21.TabIndex = 4;
            this.field21.UseVisualStyleBackColor = false;
            // 
            // field31
            // 
            this.field31.BackColor = System.Drawing.Color.Transparent;
            this.field31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field31.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field31.Location = new System.Drawing.Point(202, 199);
            this.field31.Name = "field31";
            this.field31.Size = new System.Drawing.Size(65, 68);
            this.field31.TabIndex = 4;
            this.field31.UseVisualStyleBackColor = false;
            // 
            // field25
            // 
            this.field25.BackColor = System.Drawing.Color.Transparent;
            this.field25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field25.Location = new System.Drawing.Point(402, 134);
            this.field25.Name = "field25";
            this.field25.Size = new System.Drawing.Size(65, 65);
            this.field25.TabIndex = 4;
            this.field25.UseVisualStyleBackColor = false;
            // 
            // field23
            // 
            this.field23.BackColor = System.Drawing.Color.Transparent;
            this.field23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field23.Location = new System.Drawing.Point(268, 134);
            this.field23.Name = "field23";
            this.field23.Size = new System.Drawing.Size(65, 65);
            this.field23.TabIndex = 4;
            this.field23.UseVisualStyleBackColor = false;
            // 
            // field34
            // 
            this.field34.BackColor = System.Drawing.Color.Transparent;
            this.field34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field34.Location = new System.Drawing.Point(402, 199);
            this.field34.Name = "field34";
            this.field34.Size = new System.Drawing.Size(65, 68);
            this.field34.TabIndex = 4;
            this.field34.UseVisualStyleBackColor = false;
            // 
            // field24
            // 
            this.field24.BackColor = System.Drawing.Color.Transparent;
            this.field24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field24.Location = new System.Drawing.Point(334, 134);
            this.field24.Name = "field24";
            this.field24.Size = new System.Drawing.Size(65, 65);
            this.field24.TabIndex = 4;
            this.field24.UseVisualStyleBackColor = false;
            // 
            // field32
            // 
            this.field32.BackColor = System.Drawing.Color.Transparent;
            this.field32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field32.Location = new System.Drawing.Point(268, 199);
            this.field32.Name = "field32";
            this.field32.Size = new System.Drawing.Size(65, 68);
            this.field32.TabIndex = 4;
            this.field32.UseVisualStyleBackColor = false;
            // 
            // field26
            // 
            this.field26.BackColor = System.Drawing.Color.Transparent;
            this.field26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field26.Location = new System.Drawing.Point(466, 134);
            this.field26.Name = "field26";
            this.field26.Size = new System.Drawing.Size(69, 65);
            this.field26.TabIndex = 4;
            this.field26.UseVisualStyleBackColor = false;
            // 
            // field33
            // 
            this.field33.BackColor = System.Drawing.Color.Transparent;
            this.field33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field33.Location = new System.Drawing.Point(334, 199);
            this.field33.Name = "field33";
            this.field33.Size = new System.Drawing.Size(65, 68);
            this.field33.TabIndex = 4;
            this.field33.UseVisualStyleBackColor = false;
            // 
            // field35
            // 
            this.field35.BackColor = System.Drawing.Color.Transparent;
            this.field35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field35.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field35.Location = new System.Drawing.Point(466, 199);
            this.field35.Name = "field35";
            this.field35.Size = new System.Drawing.Size(69, 68);
            this.field35.TabIndex = 4;
            this.field35.UseVisualStyleBackColor = false;
            // 
            // field27
            // 
            this.field27.BackColor = System.Drawing.Color.Transparent;
            this.field27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field27.Location = new System.Drawing.Point(536, 134);
            this.field27.Name = "field27";
            this.field27.Size = new System.Drawing.Size(64, 65);
            this.field27.TabIndex = 4;
            this.field27.UseVisualStyleBackColor = false;
            // 
            // field36
            // 
            this.field36.BackColor = System.Drawing.Color.Transparent;
            this.field36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field36.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field36.Location = new System.Drawing.Point(536, 199);
            this.field36.Name = "field36";
            this.field36.Size = new System.Drawing.Size(64, 68);
            this.field36.TabIndex = 4;
            this.field36.UseVisualStyleBackColor = false;
            // 
            // field28
            // 
            this.field28.BackColor = System.Drawing.Color.Transparent;
            this.field28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field28.Location = new System.Drawing.Point(2, 199);
            this.field28.Name = "field28";
            this.field28.Size = new System.Drawing.Size(65, 68);
            this.field28.TabIndex = 4;
            this.field28.UseVisualStyleBackColor = false;
            // 
            // field29
            // 
            this.field29.BackColor = System.Drawing.Color.Transparent;
            this.field29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field29.Location = new System.Drawing.Point(68, 199);
            this.field29.Name = "field29";
            this.field29.Size = new System.Drawing.Size(65, 68);
            this.field29.TabIndex = 4;
            this.field29.UseVisualStyleBackColor = false;
            // 
            // field30
            // 
            this.field30.BackColor = System.Drawing.Color.Transparent;
            this.field30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field30.Location = new System.Drawing.Point(134, 199);
            this.field30.Name = "field30";
            this.field30.Size = new System.Drawing.Size(65, 68);
            this.field30.TabIndex = 4;
            this.field30.UseVisualStyleBackColor = false;
            // 
            // field46
            // 
            this.field46.BackColor = System.Drawing.Color.Transparent;
            this.field46.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field46.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field46.Location = new System.Drawing.Point(2, 333);
            this.field46.Name = "field46";
            this.field46.Size = new System.Drawing.Size(65, 66);
            this.field46.TabIndex = 4;
            this.field46.UseVisualStyleBackColor = false;
            // 
            // field37
            // 
            this.field37.BackColor = System.Drawing.Color.Transparent;
            this.field37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field37.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field37.Location = new System.Drawing.Point(2, 267);
            this.field37.Name = "field37";
            this.field37.Size = new System.Drawing.Size(65, 66);
            this.field37.TabIndex = 4;
            this.field37.UseVisualStyleBackColor = false;
            // 
            // field47
            // 
            this.field47.BackColor = System.Drawing.Color.Transparent;
            this.field47.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field47.Location = new System.Drawing.Point(68, 333);
            this.field47.Name = "field47";
            this.field47.Size = new System.Drawing.Size(65, 66);
            this.field47.TabIndex = 4;
            this.field47.UseVisualStyleBackColor = false;
            // 
            // field38
            // 
            this.field38.BackColor = System.Drawing.Color.Transparent;
            this.field38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field38.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field38.Location = new System.Drawing.Point(68, 267);
            this.field38.Name = "field38";
            this.field38.Size = new System.Drawing.Size(65, 66);
            this.field38.TabIndex = 4;
            this.field38.UseVisualStyleBackColor = false;
            // 
            // field49
            // 
            this.field49.BackColor = System.Drawing.Color.Transparent;
            this.field49.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field49.Location = new System.Drawing.Point(202, 333);
            this.field49.Name = "field49";
            this.field49.Size = new System.Drawing.Size(65, 66);
            this.field49.TabIndex = 4;
            this.field49.UseVisualStyleBackColor = false;
            // 
            // field40
            // 
            this.field40.BackColor = System.Drawing.Color.Transparent;
            this.field40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field40.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field40.Location = new System.Drawing.Point(202, 268);
            this.field40.Name = "field40";
            this.field40.Size = new System.Drawing.Size(65, 65);
            this.field40.TabIndex = 4;
            this.field40.UseVisualStyleBackColor = false;
            // 
            // field48
            // 
            this.field48.BackColor = System.Drawing.Color.Transparent;
            this.field48.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field48.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field48.Location = new System.Drawing.Point(134, 333);
            this.field48.Name = "field48";
            this.field48.Size = new System.Drawing.Size(65, 66);
            this.field48.TabIndex = 4;
            this.field48.UseVisualStyleBackColor = false;
            // 
            // field39
            // 
            this.field39.BackColor = System.Drawing.Color.Transparent;
            this.field39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field39.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field39.Location = new System.Drawing.Point(134, 267);
            this.field39.Name = "field39";
            this.field39.Size = new System.Drawing.Size(65, 66);
            this.field39.TabIndex = 4;
            this.field39.UseVisualStyleBackColor = false;
            // 
            // field52
            // 
            this.field52.BackColor = System.Drawing.Color.Transparent;
            this.field52.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field52.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field52.Location = new System.Drawing.Point(402, 333);
            this.field52.Name = "field52";
            this.field52.Size = new System.Drawing.Size(65, 66);
            this.field52.TabIndex = 4;
            this.field52.UseVisualStyleBackColor = false;
            // 
            // field43
            // 
            this.field43.BackColor = System.Drawing.Color.Transparent;
            this.field43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field43.Location = new System.Drawing.Point(402, 268);
            this.field43.Name = "field43";
            this.field43.Size = new System.Drawing.Size(65, 65);
            this.field43.TabIndex = 4;
            this.field43.UseVisualStyleBackColor = false;
            // 
            // field50
            // 
            this.field50.BackColor = System.Drawing.Color.Transparent;
            this.field50.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field50.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field50.Location = new System.Drawing.Point(268, 333);
            this.field50.Name = "field50";
            this.field50.Size = new System.Drawing.Size(65, 66);
            this.field50.TabIndex = 4;
            this.field50.UseVisualStyleBackColor = false;
            // 
            // field41
            // 
            this.field41.BackColor = System.Drawing.Color.Transparent;
            this.field41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field41.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field41.Location = new System.Drawing.Point(268, 268);
            this.field41.Name = "field41";
            this.field41.Size = new System.Drawing.Size(65, 65);
            this.field41.TabIndex = 4;
            this.field41.UseVisualStyleBackColor = false;
            // 
            // field51
            // 
            this.field51.BackColor = System.Drawing.Color.Transparent;
            this.field51.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field51.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field51.Location = new System.Drawing.Point(334, 333);
            this.field51.Name = "field51";
            this.field51.Size = new System.Drawing.Size(65, 66);
            this.field51.TabIndex = 4;
            this.field51.UseVisualStyleBackColor = false;
            // 
            // field42
            // 
            this.field42.BackColor = System.Drawing.Color.Transparent;
            this.field42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field42.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field42.Location = new System.Drawing.Point(334, 268);
            this.field42.Name = "field42";
            this.field42.Size = new System.Drawing.Size(65, 65);
            this.field42.TabIndex = 4;
            this.field42.UseVisualStyleBackColor = false;
            // 
            // field53
            // 
            this.field53.BackColor = System.Drawing.Color.Transparent;
            this.field53.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field53.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field53.Location = new System.Drawing.Point(466, 333);
            this.field53.Name = "field53";
            this.field53.Size = new System.Drawing.Size(69, 66);
            this.field53.TabIndex = 4;
            this.field53.UseVisualStyleBackColor = false;
            // 
            // field44
            // 
            this.field44.BackColor = System.Drawing.Color.Transparent;
            this.field44.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field44.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field44.Location = new System.Drawing.Point(466, 268);
            this.field44.Name = "field44";
            this.field44.Size = new System.Drawing.Size(69, 65);
            this.field44.TabIndex = 4;
            this.field44.UseVisualStyleBackColor = false;
            // 
            // field45
            // 
            this.field45.BackColor = System.Drawing.Color.Transparent;
            this.field45.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field45.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field45.Location = new System.Drawing.Point(536, 268);
            this.field45.Name = "field45";
            this.field45.Size = new System.Drawing.Size(64, 65);
            this.field45.TabIndex = 4;
            this.field45.UseVisualStyleBackColor = false;
            // 
            // field54
            // 
            this.field54.BackColor = System.Drawing.Color.Transparent;
            this.field54.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field54.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field54.Location = new System.Drawing.Point(536, 333);
            this.field54.Name = "field54";
            this.field54.Size = new System.Drawing.Size(64, 66);
            this.field54.TabIndex = 4;
            this.field54.UseVisualStyleBackColor = false;
            // 
            // field73
            // 
            this.field73.BackColor = System.Drawing.Color.Transparent;
            this.field73.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field73.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field73.Location = new System.Drawing.Point(2, 533);
            this.field73.Name = "field73";
            this.field73.Size = new System.Drawing.Size(65, 66);
            this.field73.TabIndex = 4;
            this.field73.UseVisualStyleBackColor = false;
            // 
            // field64
            // 
            this.field64.BackColor = System.Drawing.Color.Transparent;
            this.field64.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field64.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field64.Location = new System.Drawing.Point(2, 467);
            this.field64.Name = "field64";
            this.field64.Size = new System.Drawing.Size(65, 66);
            this.field64.TabIndex = 4;
            this.field64.UseVisualStyleBackColor = false;
            // 
            // field74
            // 
            this.field74.BackColor = System.Drawing.Color.Transparent;
            this.field74.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field74.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field74.Location = new System.Drawing.Point(68, 533);
            this.field74.Name = "field74";
            this.field74.Size = new System.Drawing.Size(65, 66);
            this.field74.TabIndex = 4;
            this.field74.UseVisualStyleBackColor = false;
            // 
            // field65
            // 
            this.field65.BackColor = System.Drawing.Color.Transparent;
            this.field65.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field65.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field65.Location = new System.Drawing.Point(68, 467);
            this.field65.Name = "field65";
            this.field65.Size = new System.Drawing.Size(65, 66);
            this.field65.TabIndex = 4;
            this.field65.UseVisualStyleBackColor = false;
            // 
            // field76
            // 
            this.field76.BackColor = System.Drawing.Color.Transparent;
            this.field76.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field76.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field76.Location = new System.Drawing.Point(202, 533);
            this.field76.Name = "field76";
            this.field76.Size = new System.Drawing.Size(65, 66);
            this.field76.TabIndex = 4;
            this.field76.UseVisualStyleBackColor = false;
            // 
            // field67
            // 
            this.field67.BackColor = System.Drawing.Color.Transparent;
            this.field67.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field67.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field67.Location = new System.Drawing.Point(202, 468);
            this.field67.Name = "field67";
            this.field67.Size = new System.Drawing.Size(65, 65);
            this.field67.TabIndex = 4;
            this.field67.UseVisualStyleBackColor = false;
            // 
            // field75
            // 
            this.field75.BackColor = System.Drawing.Color.Transparent;
            this.field75.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field75.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field75.Location = new System.Drawing.Point(134, 533);
            this.field75.Name = "field75";
            this.field75.Size = new System.Drawing.Size(65, 66);
            this.field75.TabIndex = 4;
            this.field75.UseVisualStyleBackColor = false;
            // 
            // field58
            // 
            this.field58.BackColor = System.Drawing.Color.Transparent;
            this.field58.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field58.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field58.Location = new System.Drawing.Point(202, 399);
            this.field58.Name = "field58";
            this.field58.Size = new System.Drawing.Size(65, 68);
            this.field58.TabIndex = 4;
            this.field58.UseVisualStyleBackColor = false;
            // 
            // field55
            // 
            this.field55.BackColor = System.Drawing.Color.Transparent;
            this.field55.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field55.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field55.Location = new System.Drawing.Point(2, 399);
            this.field55.Name = "field55";
            this.field55.Size = new System.Drawing.Size(65, 68);
            this.field55.TabIndex = 4;
            this.field55.UseVisualStyleBackColor = false;
            // 
            // field66
            // 
            this.field66.BackColor = System.Drawing.Color.Transparent;
            this.field66.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field66.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field66.Location = new System.Drawing.Point(134, 467);
            this.field66.Name = "field66";
            this.field66.Size = new System.Drawing.Size(65, 66);
            this.field66.TabIndex = 4;
            this.field66.UseVisualStyleBackColor = false;
            // 
            // field79
            // 
            this.field79.BackColor = System.Drawing.Color.Transparent;
            this.field79.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field79.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field79.Location = new System.Drawing.Point(402, 533);
            this.field79.Name = "field79";
            this.field79.Size = new System.Drawing.Size(65, 66);
            this.field79.TabIndex = 4;
            this.field79.UseVisualStyleBackColor = false;
            // 
            // field70
            // 
            this.field70.BackColor = System.Drawing.Color.Transparent;
            this.field70.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field70.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field70.Location = new System.Drawing.Point(402, 468);
            this.field70.Name = "field70";
            this.field70.Size = new System.Drawing.Size(65, 65);
            this.field70.TabIndex = 4;
            this.field70.UseVisualStyleBackColor = false;
            // 
            // field77
            // 
            this.field77.BackColor = System.Drawing.Color.Transparent;
            this.field77.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field77.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field77.Location = new System.Drawing.Point(268, 533);
            this.field77.Name = "field77";
            this.field77.Size = new System.Drawing.Size(65, 66);
            this.field77.TabIndex = 4;
            this.field77.UseVisualStyleBackColor = false;
            // 
            // field61
            // 
            this.field61.BackColor = System.Drawing.Color.Transparent;
            this.field61.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field61.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field61.Location = new System.Drawing.Point(402, 399);
            this.field61.Name = "field61";
            this.field61.Size = new System.Drawing.Size(65, 68);
            this.field61.TabIndex = 4;
            this.field61.UseVisualStyleBackColor = false;
            // 
            // field68
            // 
            this.field68.BackColor = System.Drawing.Color.Transparent;
            this.field68.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field68.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field68.Location = new System.Drawing.Point(268, 468);
            this.field68.Name = "field68";
            this.field68.Size = new System.Drawing.Size(65, 65);
            this.field68.TabIndex = 4;
            this.field68.UseVisualStyleBackColor = false;
            // 
            // field78
            // 
            this.field78.BackColor = System.Drawing.Color.Transparent;
            this.field78.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field78.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field78.Location = new System.Drawing.Point(334, 533);
            this.field78.Name = "field78";
            this.field78.Size = new System.Drawing.Size(65, 66);
            this.field78.TabIndex = 4;
            this.field78.UseVisualStyleBackColor = false;
            // 
            // field59
            // 
            this.field59.BackColor = System.Drawing.Color.Transparent;
            this.field59.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field59.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field59.Location = new System.Drawing.Point(268, 399);
            this.field59.Name = "field59";
            this.field59.Size = new System.Drawing.Size(65, 68);
            this.field59.TabIndex = 4;
            this.field59.UseVisualStyleBackColor = false;
            // 
            // field56
            // 
            this.field56.BackColor = System.Drawing.Color.Transparent;
            this.field56.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field56.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field56.Location = new System.Drawing.Point(68, 399);
            this.field56.Name = "field56";
            this.field56.Size = new System.Drawing.Size(65, 68);
            this.field56.TabIndex = 4;
            this.field56.UseVisualStyleBackColor = false;
            // 
            // field69
            // 
            this.field69.BackColor = System.Drawing.Color.Transparent;
            this.field69.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field69.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field69.Location = new System.Drawing.Point(334, 468);
            this.field69.Name = "field69";
            this.field69.Size = new System.Drawing.Size(65, 65);
            this.field69.TabIndex = 4;
            this.field69.UseVisualStyleBackColor = false;
            // 
            // field80
            // 
            this.field80.BackColor = System.Drawing.Color.Transparent;
            this.field80.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field80.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field80.Location = new System.Drawing.Point(466, 533);
            this.field80.Name = "field80";
            this.field80.Size = new System.Drawing.Size(69, 66);
            this.field80.TabIndex = 4;
            this.field80.UseVisualStyleBackColor = false;
            // 
            // field71
            // 
            this.field71.BackColor = System.Drawing.Color.Transparent;
            this.field71.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field71.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field71.Location = new System.Drawing.Point(466, 468);
            this.field71.Name = "field71";
            this.field71.Size = new System.Drawing.Size(69, 65);
            this.field71.TabIndex = 4;
            this.field71.UseVisualStyleBackColor = false;
            // 
            // field60
            // 
            this.field60.BackColor = System.Drawing.Color.Transparent;
            this.field60.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field60.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field60.Location = new System.Drawing.Point(334, 399);
            this.field60.Name = "field60";
            this.field60.Size = new System.Drawing.Size(65, 68);
            this.field60.TabIndex = 4;
            this.field60.UseVisualStyleBackColor = false;
            // 
            // field57
            // 
            this.field57.BackColor = System.Drawing.Color.Transparent;
            this.field57.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field57.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field57.Location = new System.Drawing.Point(134, 399);
            this.field57.Name = "field57";
            this.field57.Size = new System.Drawing.Size(65, 68);
            this.field57.TabIndex = 4;
            this.field57.UseVisualStyleBackColor = false;
            // 
            // field62
            // 
            this.field62.BackColor = System.Drawing.Color.Transparent;
            this.field62.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field62.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field62.Location = new System.Drawing.Point(466, 399);
            this.field62.Name = "field62";
            this.field62.Size = new System.Drawing.Size(69, 68);
            this.field62.TabIndex = 4;
            this.field62.UseVisualStyleBackColor = false;
            // 
            // field72
            // 
            this.field72.BackColor = System.Drawing.Color.Transparent;
            this.field72.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field72.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field72.Location = new System.Drawing.Point(536, 468);
            this.field72.Name = "field72";
            this.field72.Size = new System.Drawing.Size(64, 65);
            this.field72.TabIndex = 4;
            this.field72.UseVisualStyleBackColor = false;
            // 
            // field81
            // 
            this.field81.BackColor = System.Drawing.Color.Transparent;
            this.field81.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field81.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field81.Location = new System.Drawing.Point(536, 533);
            this.field81.Name = "field81";
            this.field81.Size = new System.Drawing.Size(64, 66);
            this.field81.TabIndex = 4;
            this.field81.UseVisualStyleBackColor = false;
            // 
            // field63
            // 
            this.field63.BackColor = System.Drawing.Color.Transparent;
            this.field63.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.field63.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.field63.Location = new System.Drawing.Point(536, 399);
            this.field63.Name = "field63";
            this.field63.Size = new System.Drawing.Size(64, 68);
            this.field63.TabIndex = 4;
            this.field63.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(642, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Time:";
            // 
            // currentTime
            // 
            this.currentTime.AutoSize = true;
            this.currentTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.currentTime.Location = new System.Drawing.Point(642, 158);
            this.currentTime.Name = "currentTime";
            this.currentTime.Size = new System.Drawing.Size(66, 25);
            this.currentTime.TabIndex = 6;
            this.currentTime.Text = "00:00";
            // 
            // hideBoard
            // 
            this.hideBoard.Image = global::Sudoku.Properties.Resources.questionMark;
            this.hideBoard.InitialImage = global::Sudoku.Properties.Resources.questionMark;
            this.hideBoard.Location = new System.Drawing.Point(2, 2);
            this.hideBoard.Name = "hideBoard";
            this.hideBoard.Size = new System.Drawing.Size(598, 597);
            this.hideBoard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hideBoard.TabIndex = 7;
            this.hideBoard.TabStop = false;
            this.hideBoard.Visible = false;
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(606, 549);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(130, 50);
            this.resetButton.TabIndex = 8;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(606, 493);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(130, 50);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // gameWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Sudoku.Properties.Resources.template1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(750, 621);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.hideBoard);
            this.Controls.Add(this.currentTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.field63);
            this.Controls.Add(this.field36);
            this.Controls.Add(this.field81);
            this.Controls.Add(this.field54);
            this.Controls.Add(this.field27);
            this.Controls.Add(this.field72);
            this.Controls.Add(this.field45);
            this.Controls.Add(this.field18);
            this.Controls.Add(this.field62);
            this.Controls.Add(this.field35);
            this.Controls.Add(this.field9);
            this.Controls.Add(this.field57);
            this.Controls.Add(this.field30);
            this.Controls.Add(this.field60);
            this.Controls.Add(this.field33);
            this.Controls.Add(this.field71);
            this.Controls.Add(this.field44);
            this.Controls.Add(this.field17);
            this.Controls.Add(this.field80);
            this.Controls.Add(this.field53);
            this.Controls.Add(this.field26);
            this.Controls.Add(this.field69);
            this.Controls.Add(this.field42);
            this.Controls.Add(this.field15);
            this.Controls.Add(this.field56);
            this.Controls.Add(this.field29);
            this.Controls.Add(this.field59);
            this.Controls.Add(this.field32);
            this.Controls.Add(this.field8);
            this.Controls.Add(this.field78);
            this.Controls.Add(this.field51);
            this.Controls.Add(this.field24);
            this.Controls.Add(this.field68);
            this.Controls.Add(this.field41);
            this.Controls.Add(this.field14);
            this.Controls.Add(this.field61);
            this.Controls.Add(this.field34);
            this.Controls.Add(this.field6);
            this.Controls.Add(this.field77);
            this.Controls.Add(this.field50);
            this.Controls.Add(this.field23);
            this.Controls.Add(this.field70);
            this.Controls.Add(this.field43);
            this.Controls.Add(this.field16);
            this.Controls.Add(this.field5);
            this.Controls.Add(this.field79);
            this.Controls.Add(this.field52);
            this.Controls.Add(this.field25);
            this.Controls.Add(this.field66);
            this.Controls.Add(this.field39);
            this.Controls.Add(this.field12);
            this.Controls.Add(this.field55);
            this.Controls.Add(this.field58);
            this.Controls.Add(this.field28);
            this.Controls.Add(this.field31);
            this.Controls.Add(this.field75);
            this.Controls.Add(this.field7);
            this.Controls.Add(this.field48);
            this.Controls.Add(this.field67);
            this.Controls.Add(this.field21);
            this.Controls.Add(this.field40);
            this.Controls.Add(this.field13);
            this.Controls.Add(this.field76);
            this.Controls.Add(this.field3);
            this.Controls.Add(this.field49);
            this.Controls.Add(this.field65);
            this.Controls.Add(this.field22);
            this.Controls.Add(this.field38);
            this.Controls.Add(this.field11);
            this.Controls.Add(this.field74);
            this.Controls.Add(this.field4);
            this.Controls.Add(this.field47);
            this.Controls.Add(this.field64);
            this.Controls.Add(this.field20);
            this.Controls.Add(this.field73);
            this.Controls.Add(this.field37);
            this.Controls.Add(this.field46);
            this.Controls.Add(this.field10);
            this.Controls.Add(this.field19);
            this.Controls.Add(this.field2);
            this.Controls.Add(this.field1);
            this.Controls.Add(this.pauseButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.helpButton);
            this.MaximumSize = new System.Drawing.Size(766, 660);
            this.MinimumSize = new System.Drawing.Size(766, 660);
            this.Name = "gameWindow";
            this.Text = "Game";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.gameWindow_FormClosing);
            this.Load += new System.EventHandler(this.gameWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hideBoard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button pauseButton;
        private System.Windows.Forms.Button field1;
        private System.Windows.Forms.Button field2;
        private System.Windows.Forms.Button field3;
        private System.Windows.Forms.Button field4;
        private System.Windows.Forms.Button field5;
        private System.Windows.Forms.Button field6;
        private System.Windows.Forms.Button field7;
        private System.Windows.Forms.Button field8;
        private System.Windows.Forms.Button field9;
        private System.Windows.Forms.Button field10;
        private System.Windows.Forms.Button field11;
        private System.Windows.Forms.Button field13;
        private System.Windows.Forms.Button field12;
        private System.Windows.Forms.Button field16;
        private System.Windows.Forms.Button field14;
        private System.Windows.Forms.Button field15;
        private System.Windows.Forms.Button field17;
        private System.Windows.Forms.Button field18;
        private System.Windows.Forms.Button field19;
        private System.Windows.Forms.Button field20;
        private System.Windows.Forms.Button field22;
        private System.Windows.Forms.Button field21;
        private System.Windows.Forms.Button field31;
        private System.Windows.Forms.Button field25;
        private System.Windows.Forms.Button field23;
        private System.Windows.Forms.Button field34;
        private System.Windows.Forms.Button field24;
        private System.Windows.Forms.Button field32;
        private System.Windows.Forms.Button field26;
        private System.Windows.Forms.Button field33;
        private System.Windows.Forms.Button field35;
        private System.Windows.Forms.Button field27;
        private System.Windows.Forms.Button field36;
        private System.Windows.Forms.Button field28;
        private System.Windows.Forms.Button field29;
        private System.Windows.Forms.Button field30;
        private System.Windows.Forms.Button field46;
        private System.Windows.Forms.Button field37;
        private System.Windows.Forms.Button field47;
        private System.Windows.Forms.Button field38;
        private System.Windows.Forms.Button field49;
        private System.Windows.Forms.Button field40;
        private System.Windows.Forms.Button field48;
        private System.Windows.Forms.Button field39;
        private System.Windows.Forms.Button field52;
        private System.Windows.Forms.Button field43;
        private System.Windows.Forms.Button field50;
        private System.Windows.Forms.Button field41;
        private System.Windows.Forms.Button field51;
        private System.Windows.Forms.Button field42;
        private System.Windows.Forms.Button field53;
        private System.Windows.Forms.Button field44;
        private System.Windows.Forms.Button field45;
        private System.Windows.Forms.Button field54;
        private System.Windows.Forms.Button field73;
        private System.Windows.Forms.Button field64;
        private System.Windows.Forms.Button field74;
        private System.Windows.Forms.Button field65;
        private System.Windows.Forms.Button field76;
        private System.Windows.Forms.Button field67;
        private System.Windows.Forms.Button field75;
        private System.Windows.Forms.Button field58;
        private System.Windows.Forms.Button field55;
        private System.Windows.Forms.Button field66;
        private System.Windows.Forms.Button field79;
        private System.Windows.Forms.Button field70;
        private System.Windows.Forms.Button field77;
        private System.Windows.Forms.Button field61;
        private System.Windows.Forms.Button field68;
        private System.Windows.Forms.Button field78;
        private System.Windows.Forms.Button field59;
        private System.Windows.Forms.Button field56;
        private System.Windows.Forms.Button field69;
        private System.Windows.Forms.Button field80;
        private System.Windows.Forms.Button field71;
        private System.Windows.Forms.Button field60;
        private System.Windows.Forms.Button field57;
        private System.Windows.Forms.Button field62;
        private System.Windows.Forms.Button field72;
        private System.Windows.Forms.Button field81;
        private System.Windows.Forms.Button field63;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label currentTime;
        private System.Windows.Forms.PictureBox hideBoard;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button saveButton;
    }
}