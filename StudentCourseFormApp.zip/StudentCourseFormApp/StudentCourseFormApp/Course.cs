﻿/* Name : Aravind Muvva and Abhinav Chamallamudi
 * ZID : Z1835959 and Z1826541
 * Course : CSCI 504
 * Due date : 09-27-2018
 * Purpose : to define the functionality of the course class
 */ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentCourseFormApp
{
    public class Course : IComparable
    {
        string deptCode;
        uint courseNum;
        string sectionNum;
        ushort creditHrs;
        List<int> enrolled = new List<int>();
        ushort numStudents;
        ushort maxCapacity;

        public string DEPTCODE { get { return deptCode; } 
                set {
                    if (value.Length > 4 || value.Any(char.IsLower))
                        throw new Exception("Error! Dept Code should be max of 4 UPPER CASE characters");       //get and set methods for all the variables
                    deptCode = value; } }
        public uint COURSENUM { get { return courseNum; } 
                set {
                    if (value<100 ||value>499)
                        throw new Exception("Error! Course Number Range [100,499]");
                    courseNum = value; } }
        public string SECTIONNUM { get { return sectionNum; } 
                set {
                    if (value.Length!=4)
                        throw new Exception("Error! Section Number should be of 4 alphanumeric characters.");
                    sectionNum = value; } }
        public ushort CREDITHRS { get { return creditHrs; } 
                set {
                    if (value < 0 || value > 6)
                        throw new Exception("Error! Credit Hours Range [0,6]");
                    creditHrs = value; } }
        public ushort NUMSTUDENTS { get { return numStudents; } set { numStudents = value; } }
        public ushort MAXCAPACITY { get { return maxCapacity; } set { maxCapacity = value; } }

        public List<int> ENROLLED { get { return enrolled; } set { enrolled = value; } }

        public Course()
        {
            deptCode = "";
            courseNum = 0;
            sectionNum = "";
            creditHrs = 0;
            enrolled = null;                    //default constructor
            numStudents = 0;
            maxCapacity = 0;
        }

        public Course(string p_deptCode, uint p_courseNum, string p_sectionNum, ushort p_creditHrs, ushort p_maxCapacity)
        {
            DEPTCODE = p_deptCode;
            COURSENUM = p_courseNum;
            SECTIONNUM = p_sectionNum;        //alternate constructor
            CREDITHRS = p_creditHrs;
            MAXCAPACITY = p_maxCapacity;
            NUMSTUDENTS = 0;            
        }

        public int CompareTo(object obj)
        {
            Course cs = obj as Course;
            int result= this.DEPTCODE.CompareTo(cs.DEPTCODE);
            if (result == 0)
                result = this.COURSENUM.CompareTo(cs.COURSENUM);
            return result;
        }

        public override string ToString()
        {
            return DEPTCODE + " " + COURSENUM + "-" + SECTIONNUM + " (" + NUMSTUDENTS + "/" + MAXCAPACITY + ")";  //override function
        }

        public string PrintRoster()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Course: " + ToString());     //to print the course roster including zids of students
            sb.AppendLine("-----------------------------------------------------------------");
            foreach(int z in ENROLLED)
            {
                Student st2 = MainForm.STUDENTLIST.Find(item => item.ZID.ToString() == z.ToString());
                sb.AppendLine("z"+z.ToString() + " " + st2.FNAME + ", " + st2.LNAME + " " + st2.MAJOR);
            }
            return sb.ToString();
        }

    }
}
