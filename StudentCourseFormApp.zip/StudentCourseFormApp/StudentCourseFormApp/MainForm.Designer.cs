﻿/*Name : Aravind Muvva and Abhinav Chamallamudi
 * ZID : Z1835959 and Z1826541
 * Course : CSCI 504
 * Due date : 09-27-2018
 * purpose: main form to generate the windows application
 */
namespace StudentCourseFormApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbStudents = new System.Windows.Forms.ListBox();
            this.lbCourses = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPrintRoaster = new System.Windows.Forms.Button();
            this.btnEnroll = new System.Windows.Forms.Button();
            this.btnDrop = new System.Windows.Forms.Button();
            this.txtSStudent = new System.Windows.Forms.TextBox();
            this.txtSCourse = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbAcademicYear = new System.Windows.Forms.ComboBox();
            this.cmbMajor = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.txtZID = new System.Windows.Forms.TextBox();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nudCapacity = new System.Windows.Forms.NumericUpDown();
            this.txtSectionNum = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnCourse = new System.Windows.Forms.Button();
            this.txtCourseNum = new System.Windows.Forms.TextBox();
            this.txtDept = new System.Windows.Forms.TextBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCapacity)).BeginInit();
            this.SuspendLayout();
            // label for students
            this.lbStudents.FormattingEnabled = true;
            this.lbStudents.ItemHeight = 15;
            this.lbStudents.Location = new System.Drawing.Point(533, 72);
            this.lbStudents.Name = "lbStudents";
            this.lbStudents.Size = new System.Drawing.Size(229, 409);
            this.lbStudents.TabIndex = 0;
            this.lbStudents.SelectedIndexChanged += new System.EventHandler(this.lbStudents_SelectedIndexChanged);
            // label for courses
            this.lbCourses.FormattingEnabled = true;
            this.lbCourses.ItemHeight = 15;
            this.lbCourses.Location = new System.Drawing.Point(768, 72);
            this.lbCourses.Name = "lbCourses";
            this.lbCourses.Size = new System.Drawing.Size(229, 409);
            this.lbCourses.TabIndex = 1;
            // label to print niu enrollment management system 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(501, 39);
            this.label1.TabIndex = 2;
            this.label1.Text = "NIU Enrollment Management System";
            // generating button for print roster
            this.btnPrintRoaster.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintRoaster.Location = new System.Drawing.Point(9, 74);
            this.btnPrintRoaster.Name = "btnPrintRoaster";
            this.btnPrintRoaster.Size = new System.Drawing.Size(157, 33);
            this.btnPrintRoaster.TabIndex = 4;
            this.btnPrintRoaster.Text = "Print Course Roaster";
            this.btnPrintRoaster.UseVisualStyleBackColor = true;
            this.btnPrintRoaster.Click += new System.EventHandler(this.btnPrintRoaster_Click);
            //  generating button for Enroll
            this.btnEnroll.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnroll.Location = new System.Drawing.Point(194, 74);
            this.btnEnroll.Name = "btnEnroll";
            this.btnEnroll.Size = new System.Drawing.Size(138, 33);
            this.btnEnroll.TabIndex = 5;
            this.btnEnroll.Text = "Enroll Student";
            this.btnEnroll.UseVisualStyleBackColor = true;
            this.btnEnroll.Click += new System.EventHandler(this.btnEnroll_Click); 
            // generating button for Drop
            this.btnDrop.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDrop.Location = new System.Drawing.Point(360, 74);
            this.btnDrop.Name = "btnDrop";
            this.btnDrop.Size = new System.Drawing.Size(138, 33);
            this.btnDrop.TabIndex = 6;
            this.btnDrop.Text = "Drop Student";
            this.btnDrop.UseVisualStyleBackColor = true;
            this.btnDrop.Click += new System.EventHandler(this.btnDrop_Click);
            // to generate student text
            this.txtSStudent.Location = new System.Drawing.Point(10, 37);
            this.txtSStudent.Name = "txtSStudent";
            this.txtSStudent.Size = new System.Drawing.Size(156, 23);
            this.txtSStudent.TabIndex = 1;
            // to generate course text
            this.txtSCourse.Location = new System.Drawing.Point(172, 37);
            this.txtSCourse.Name = "txtSCourse";
            this.txtSCourse.Size = new System.Drawing.Size(156, 23);
            this.txtSCourse.TabIndex = 2;
            //generating the button Search
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(334, 30);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(164, 33);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Apply Search Criteria";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // label for  student 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Search Student (by Z-ID)";
            // label for filter courses by dept
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(169, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Filter Courses (by Dept)";
            // group box which has things like print roster,enroll,search etc
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnPrintRoaster);
            this.groupBox1.Controls.Add(this.btnEnroll);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.btnDrop);
            this.groupBox1.Controls.Add(this.txtSCourse);
            this.groupBox1.Controls.Add(this.txtSStudent);
            this.groupBox1.Location = new System.Drawing.Point(11, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(503, 126);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // group box which has things like academic year, major etc.
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cmbAcademicYear);
            this.groupBox2.Controls.Add(this.cmbMajor);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnAddStudent);
            this.groupBox2.Controls.Add(this.txtZID);
            this.groupBox2.Controls.Add(this.txtStudentName);
            this.groupBox2.Location = new System.Drawing.Point(11, 214);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(503, 126);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // label for academic year
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(169, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Academic Year";
            // label for major
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Major";
            // academic year
            this.cmbAcademicYear.FormattingEnabled = true;
            this.cmbAcademicYear.Location = new System.Drawing.Point(172, 82);
            this.cmbAcademicYear.Name = "cmbAcademicYear";
            this.cmbAcademicYear.Size = new System.Drawing.Size(156, 23);
            this.cmbAcademicYear.TabIndex = 7;
            // major
            this.cmbMajor.FormattingEnabled = true;
            this.cmbMajor.Location = new System.Drawing.Point(10, 82);
            this.cmbMajor.Name = "cmbMajor";
            this.cmbMajor.Size = new System.Drawing.Size(156, 23);
            this.cmbMajor.TabIndex = 4;
            // label for first name and last name
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Last Name, First Name";
            // label for zid
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Z-ID";
            // generating add student button
            this.btnAddStudent.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStudent.Location = new System.Drawing.Point(340, 72);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(158, 33);
            this.btnAddStudent.TabIndex = 8;
            this.btnAddStudent.Text = "Add Student";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // text for ZID
            this.txtZID.Location = new System.Drawing.Point(172, 37);
            this.txtZID.Name = "txtZID";
            this.txtZID.Size = new System.Drawing.Size(156, 23);
            this.txtZID.TabIndex = 1;
            // text for student name
            this.txtStudentName.Location = new System.Drawing.Point(10, 37);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(156, 23);
            this.txtStudentName.TabIndex = 0;
            // group box which contains course, dept etc

            this.groupBox3.Controls.Add(this.nudCapacity);
            this.groupBox3.Controls.Add(this.txtSectionNum);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.btnCourse);
            this.groupBox3.Controls.Add(this.txtCourseNum);
            this.groupBox3.Controls.Add(this.txtDept);
            this.groupBox3.Location = new System.Drawing.Point(11, 358);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(503, 126);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            // nudCapacity
            this.nudCapacity.Location = new System.Drawing.Point(172, 83);
            this.nudCapacity.Name = "nudCapacity";
            this.nudCapacity.Size = new System.Drawing.Size(156, 23);
            this.nudCapacity.TabIndex = 3;
            // txtSectionNum
            this.txtSectionNum.Location = new System.Drawing.Point(9, 82);
            this.txtSectionNum.Name = "txtSectionNum";
            this.txtSectionNum.Size = new System.Drawing.Size(156, 23);
            this.txtSectionNum.TabIndex = 2;
            // label for capacity
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(169, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "Capacity";
            // label for section number
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 15);
            this.label9.TabIndex = 15;
            this.label9.Text = "Section Number";
            // label for department code
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Department Code";
            // label for course number
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(169, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "Course Number";
            // button for course
            this.btnCourse.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCourse.Location = new System.Drawing.Point(340, 72);
            this.btnCourse.Name = "btnCourse";
            this.btnCourse.Size = new System.Drawing.Size(158, 33);
            this.btnCourse.TabIndex = 4;
            this.btnCourse.Text = "Add Course";
            this.btnCourse.UseVisualStyleBackColor = true;
            this.btnCourse.Click += new System.EventHandler(this.btnCourse_Click);
            // course number text
            this.txtCourseNum.Location = new System.Drawing.Point(172, 37);
            this.txtCourseNum.Name = "txtCourseNum";
            this.txtCourseNum.Size = new System.Drawing.Size(156, 23);
            this.txtCourseNum.TabIndex = 1;
            // department number text
            this.txtDept.Location = new System.Drawing.Point(10, 37);
            this.txtDept.Name = "txtDept";
            this.txtDept.Size = new System.Drawing.Size(156, 23);
            this.txtDept.TabIndex = 0;
            // for getting the output
            this.rtbOutput.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbOutput.Location = new System.Drawing.Point(12, 490);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.Size = new System.Drawing.Size(985, 187);
            this.rtbOutput.TabIndex = 18;
            this.rtbOutput.Text = "";
            // MainForm and its layout
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 689);
            this.Controls.Add(this.rtbOutput);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbCourses);
            this.Controls.Add(this.lbStudents);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCapacity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbStudents;
        private System.Windows.Forms.ListBox lbCourses;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPrintRoaster;
        private System.Windows.Forms.Button btnEnroll;
        private System.Windows.Forms.Button btnDrop;
        private System.Windows.Forms.TextBox txtSStudent;
        private System.Windows.Forms.TextBox txtSCourse;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;    //various groupboxes,labels,textboxes defined and their working is given at top
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbAcademicYear;
        private System.Windows.Forms.ComboBox cmbMajor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.TextBox txtZID;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nudCapacity;
        private System.Windows.Forms.TextBox txtSectionNum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnCourse;
        private System.Windows.Forms.TextBox txtCourseNum;
        private System.Windows.Forms.TextBox txtDept;
        private System.Windows.Forms.RichTextBox rtbOutput;
    }
}

