﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace StudentCourseFormApp
{
    public partial class MainForm : Form
    {
        public static List<Student> _students;
        private List<Student> students = new List<Student>();
        private List<Course> courses = new List<Course>();

        public static List<Student> STUDENTLIST { get { return _students; } }

        private int ReadFiles()
        {
            try
            {
                string fileName = @"..\\..\\2188_a2_input01.txt";     //reading the input file1
                if (!File.Exists(fileName))
                    return -1;

                using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] values = line.Split(',');
                        Student _student = new Student(uint.Parse(values[0]), values[1], values[2], values[3], int.Parse(values[4]), float.Parse(values[5]));   //splitting the values accordingly
                        students.Add(_student);
                    }
                }

                string fileName2 = @"..\\..\\2188_a2_input02.txt";
                if (!File.Exists(fileName2))
                    return -2;

                using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName2))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] values = line.Split(',');
                        Course _course = new Course(values[0], uint.Parse(values[1]), values[2], ushort.Parse(values[3]), ushort.Parse(values[4]));
                        courses.Add(_course);
                    }
                }

                string fileName3 = @"..\\..\\2188_a2_input03.txt";
                if (!File.Exists(fileName3))
                    return -3;

                using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName3))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if(line.Trim().Length>0)
                        {
                            cmbMajor.Items.Add(line);
                        }
                    }
                }

                cmbAcademicYear.DataSource = Enum.GetValues(typeof(Student.academic_year));
                cmbAcademicYear.SelectedIndex = -1;
                
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return -99;
            }
        }

        private void LoadList()
        {
            try
            {
                lbStudents.Items.Clear();
                lbCourses.Items.Clear();

                students.Sort();
                foreach(Student st in students)
                {
                    lbStudents.Items.Add("z" + st.ZID + " -- " + st.LNAME + ", " + st.FNAME);
                }

                courses.Sort();
                foreach (Course cs in courses)
                {
                    lbCourses.Items.Add(cs.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public MainForm()
        {
            try
            {
                InitializeComponent();     //main form initialization

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                int x = ReadFiles();
                if (x == -99)
                    return;
                if (x == -1)
                {
                    MessageBox.Show("Error! Student's File cannot be found.");    //if the files are not found
                    Environment.Exit(0);
                }
                if (x == -2)
                {
                    MessageBox.Show("Error! Courses's File cannot be found.");
                    Environment.Exit(0);
                }
                LoadList();
                _students = students;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            try
            { 
                if(lbStudents.SelectedIndex==-1)
                {
                    MessageBox.Show("Please select student to enroll.");     //error to show if no student is selected or course is selected
                    return;
                }

                if (lbCourses.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select course to enroll.");
                    return;
                }
                string zid = lbStudents.SelectedItem.ToString().Substring(1, lbStudents.SelectedItem.ToString().IndexOf(' ')).Trim();
                string dept = lbCourses.SelectedItem.ToString().Substring(0, lbCourses.SelectedItem.ToString().IndexOf(' '));
                string cnum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                cnum = cnum.Substring(0, cnum.IndexOf('-'));
                string snum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                snum = snum.Substring(snum.IndexOf('-')+1,snum.IndexOf(' ')-snum.IndexOf('-')-1);


                Student st = students.Find(item => item.ZID.ToString() == zid);
                Course cs = courses.Find(item => item.DEPTCODE.ToString() == dept && item.COURSENUM.ToString() == cnum && item.SECTIONNUM.ToString() == snum);
                int temp = st.Enroll(cs);
                switch (temp)
                {
                    case 0:
                        cs.NUMSTUDENTS += 1;
                        rtbOutput.Text = "***Student Enrolled***";
                        LoadList();
                        break;
                    case 5:
                        rtbOutput.Text = "Error! Course exceeding maximum capacity.";
                        break;
                    case 10:
                        rtbOutput.Text = "Error! Student already enrolled.";  // all the possible types of errors are printed
                        break;
                    case 15:
                        rtbOutput.Text = "Error! Student's total credit hours will exceed 18.";
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDrop_Click(object sender, EventArgs e)
        {
             try
             {
                 if (lbStudents.SelectedIndex == -1)
                 {
                     MessageBox.Show("Please select student to enroll.");
                     return;
                 }

                 if (lbCourses.SelectedIndex == -1)
                 {
                     MessageBox.Show("Please select course to enroll.");
                     return;
                 }
                 string zid = lbStudents.SelectedItem.ToString().Substring(1, lbStudents.SelectedItem.ToString().IndexOf(' ')).Trim();
                 string dept = lbCourses.SelectedItem.ToString().Substring(0, lbCourses.SelectedItem.ToString().IndexOf(' '));
                 string cnum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                 cnum = cnum.Substring(0, cnum.IndexOf('-'));
                 string snum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                 snum = snum.Substring(snum.IndexOf('-') + 1, snum.IndexOf(' ') - snum.IndexOf('-') - 1);


                 Student st = students.Find(item => item.ZID.ToString() == zid);
                 Course cs = courses.Find(item => item.DEPTCODE.ToString() == dept && item.COURSENUM.ToString() == cnum && item.SECTIONNUM.ToString() == snum);
                 int temp = st.Drop(cs);
                 switch (temp)
                 {
                     case 0:
                         cs.NUMSTUDENTS -= 1;
                         rtbOutput.Text = "***Student Dropped***";
                         LoadList();
                         break;
                     case 20:
                         rtbOutput.Text = "Error! Student not enrolled.";
                         break;
                 }
             }
             catch (Exception ex)
             {
                 MessageBox.Show(ex.Message);
             }
        }

        private void btnPrintRoaster_Click(object sender, EventArgs e)
        {
            try
            {
                if (lbCourses.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select course to print roster.");     
                    return;
                }
                string dept = lbCourses.SelectedItem.ToString().Substring(0, lbCourses.SelectedItem.ToString().IndexOf(' '));
                string cnum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                cnum = cnum.Substring(0, cnum.IndexOf('-'));
                string snum = lbCourses.SelectedItem.ToString().Replace(dept, "").Trim();
                snum = snum.Substring(snum.IndexOf('-') + 1, snum.IndexOf(' ') - snum.IndexOf('-') - 1);

                Course cs = courses.Find(item => item.DEPTCODE.ToString() == dept && item.COURSENUM.ToString() == cnum && item.SECTIONNUM.ToString() == snum);
                rtbOutput.Text = cs.PrintRoster();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                bool found1 = false, found2 = false;
                if(txtSStudent.Text.Trim().Length==0 && txtSCourse.Text.Trim().Length==0)
                {
                    MessageBox.Show("Please input atleast one criteria for search");
                    LoadList();
                    return;
                }

                if (txtSStudent.Text.Trim().Length > 0)
                {
                    lbStudents.Items.Clear();
                    students.Sort();
                    foreach (Student st in students)
                    {
                        if (("z" + st.ZID).ToString().StartsWith(txtSStudent.Text.Trim()))
                        {
                            lbStudents.Items.Add("z" + st.ZID + " -- " + st.LNAME + ", " + st.FNAME);
                            found1 = true;
                        }
                    }
                }
                if (txtSCourse.Text.Trim().Length >= 4)
                {
                    lbCourses.Items.Clear();
                    courses.Sort();
                    foreach (Course cs in courses)
                    {
                        if (cs.DEPTCODE.ToString().StartsWith(txtSCourse.Text.Trim()))
                        {
                            lbCourses.Items.Add(cs.ToString());
                            found2 = true;
                        }
                    }
                }

                rtbOutput.Clear();
                if (!found1 && txtSStudent.Text.Trim().Length > 0)
                {
                    rtbOutput.Text = "Error! Nothing matched for Student (by ZID) Search" + Environment.NewLine;   //printing all the exceptions
                    lbStudents.Items.Clear();
                    students.Sort();
                    foreach (Student st in students)
                    {
                        lbStudents.Items.Add("z" + st.ZID + " -- " + st.LNAME + ", " + st.FNAME);
                    }                    
                }
                if (!found2 && txtSCourse.Text.Trim().Length >= 4)
                {
                    rtbOutput.Text = rtbOutput.Text  + "Error! Nothing matched for Course (by Dept) Search";
                    lbCourses.Items.Clear();
                    courses.Sort();
                    foreach (Course cs in courses)
                    {
                        lbCourses.Items.Add(cs.ToString());
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            try
            {
                double temp=0;
                if (txtStudentName.Text.Trim().Length == 0 || txtZID.Text.Trim().Length == 0 || cmbMajor.SelectedIndex==-1 || cmbAcademicYear.SelectedIndex==-1)
                {
                    MessageBox.Show("Please select all fields for adding student");
                    return;
                }

                if(!txtStudentName.Text.Contains(','))
                {
                    MessageBox.Show("Please input full name of student (comma separated)");
                    return;
                }

                if ((txtZID.Text.Length == 7 && Double.TryParse(txtZID.Text, out temp)) || (txtZID.Text.Length == 8 && txtZID.Text.Substring(0, 1).ToUpper().Equals("Z") && Double.TryParse(txtZID.Text.Substring(1), out temp)))
                    temp = 0;
                else
                {
                    MessageBox.Show("Please input Z-ID in correct format");
                    return;
                }

                uint p_zid = txtZID.Text.Length == 8 ? Convert.ToUInt32(txtZID.Text.Substring(1)) : Convert.ToUInt32(txtZID.Text);
                string p_lname=txtStudentName.Text.Substring(0, txtStudentName.Text.IndexOf(',')).Trim();                    
                string p_fname=txtStudentName.Text.Substring(txtStudentName.Text.IndexOf(',')+1).Trim();
                string p_major=cmbMajor.SelectedText;
                int p_accyear=cmbAcademicYear.SelectedIndex+1;
                float p_gpa = ((float)0.000);
                Student stnew = new Student(p_zid, p_fname, p_lname, p_major, p_accyear, p_gpa);
                students.Add(stnew);
                LoadList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            try
            {
                Regex r = new Regex("^[a-zA-Z0-9]*$");
                Regex r2 = new Regex("^[0-9]*$");
                if (txtDept.Text.Trim().Length == 0 || txtCourseNum.Text.Trim().Length == 0 || txtSectionNum.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Please select all fields for adding course");
                    return;
                }
                if(nudCapacity.Value==0)
                {
                    MessageBox.Show("Please input capacity value greater than zero");
                    return;
                }
                if (!(txtDept.Text.Length==4 && r.IsMatch(txtDept.Text)))
                {
                    MessageBox.Show("Department code should be exactly four alphanumeric characters");
                    return;
                }
                if (!(txtCourseNum.Text.Length == 3 && r2.IsMatch(txtCourseNum.Text)))
                {
                    MessageBox.Show("Course number should be exactly three digits");
                    return;
                }
                if (!(txtSectionNum.Text.Length == 4 && r.IsMatch(txtSectionNum.Text)))
                {
                    MessageBox.Show("Section number should be exactly four alphanumeric characters");
                    return;
                }

                string p_deptCode=txtDept.Text;
                uint p_courseNum=Convert.ToUInt32(txtCourseNum.Text);
                string p_sectionNum=txtSectionNum.Text;
                ushort p_creditHrs=0;
                ushort p_maxCapacity = Convert.ToUInt16(nudCapacity.Value);

                Course csnew = new Course(p_deptCode, p_courseNum, p_sectionNum, p_creditHrs, p_maxCapacity);
                courses.Add(csnew);
                LoadList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            try 
            {
                uint s_zid = Convert.ToUInt32(lbStudents.SelectedItem.ToString().Substring(1, lbStudents.SelectedItem.ToString().IndexOf(' ') - 1));
                StringBuilder sb = new StringBuilder(); 
                rtbOutput.Clear();
                foreach (Student st in students)
                {
                    if (st.ZID == s_zid)
                    {
                        sb.AppendLine(st.ToString());
                    }
                }
                sb.AppendLine("---------------------------------------------------------------------------");
                
                foreach (Course cs in courses)
                {
                    if (cs.ENROLLED.Contains(Convert.ToInt32(s_zid)))
                    {
                        sb.AppendLine(cs.ToString());
                    }
                }
                rtbOutput.Text = sb.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

