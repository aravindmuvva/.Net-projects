﻿/* Name : Abhinav Chamallamudi and Aravind Muvva
 * ZID : Z1826541 and Z1835959
 * Course : CSCI 504
 * Assignment Number : 1
 * Purpose: A program to create classes Student and Course and develop the mentioned methods and create a menu to show the results.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SudentCourseApp
{
    class Course : IComparable
    {
        string deptCode;
        uint courseNum;    //initializing the variables
        string sectionNum;
        ushort creditHrs;
        List<int> enrolled = new List<int>();
        ushort numStudents;
        ushort maxCapacity;

        public string DEPTCODE { get { return deptCode; } //using get and set functions for each variable
                set {
                    if (value.Length > 4 || value.Any(char.IsLower))
                        throw new Exception("Error! Dept Code should be max of 4 UPPER CASE characters");
                    deptCode = value; } }
        public uint COURSENUM { get { return courseNum; } 
                set {
                    if (value<100 ||value>499)
                        throw new Exception("Error! Course Number Range [100,499]");
                    courseNum = value; } }
        public string SECTIONNUM { get { return sectionNum; } 
                set {
                    if (value.Length!=4)
                        throw new Exception("Error! Section Number should be of 4 alphanumeric characters.");
                    sectionNum = value; } }
        public ushort CREDITHRS { get { return creditHrs; } 
                set {
                    if (value < 0 || value > 6)
                        throw new Exception("Error! Credit Hours Range [0,6]");
                    creditHrs = value; } }
        public ushort NUMSTUDENTS { get { return numStudents; } set { numStudents = value; } }
        public ushort MAXCAPACITY { get { return maxCapacity; } set { maxCapacity = value; } }

        public List<int> ENROLLED { get { return enrolled; } set { enrolled = value; } }

        public Course()    //default constructor
        {
            deptCode = "";
            courseNum = 0;
            sectionNum = "";
            creditHrs = 0;
            enrolled = null;
            numStudents = 0;
            maxCapacity = 0;
        }

        public Course(string p_deptCode, uint p_courseNum, string p_sectionNum, ushort p_creditHrs, ushort p_maxCapacity)  //alternate constructor
        {
            DEPTCODE = p_deptCode;
            COURSENUM = p_courseNum;
            SECTIONNUM = p_sectionNum;
            CREDITHRS = p_creditHrs;
            MAXCAPACITY = p_maxCapacity;
            NUMSTUDENTS = 0;            
        }

        public int CompareTo(object obj)
        {
            Course cs = obj as Course;
            int result= this.DEPTCODE.CompareTo(cs.DEPTCODE);
            if (result == 0)
                result = this.COURSENUM.CompareTo(cs.COURSENUM);
            return result;
        }

        public override string ToString()
        {
            return DEPTCODE + " " + COURSENUM + "-" + SECTIONNUM + " (" + NUMSTUDENTS + "/" + MAXCAPACITY + ")";
        }

        public void PrintRoster()    // to print the course roster i.e to show the students name and total number of students enrolled in a particular course
        {
            Console.WriteLine("Course: " + ToString());
            Console.WriteLine("-----------------------------------------------------------------");
            foreach(int z in ENROLLED)
            {   
                Student st2 = Program.students.Find(item => item.ZID.ToString() == z.ToString());
                Console.WriteLine(z.ToString() + " " + st2.FNAME + " " + st2.LNAME + " " + st2.MAJOR);
            }
        }

    }
}
