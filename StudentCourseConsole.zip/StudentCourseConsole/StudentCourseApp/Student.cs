﻿/* Name : Abhinav Chamallamudi and Aravind Muvva
 * ZID : Z1826541 and Z1835959
 * Course : CSCI 504
 * Assignment Number : 1
 * Purpose: A program to create classes Student and Course and develop the mentioned methods and create a menu to show the results.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SudentCourseApp
{    
    class Student : IComparable
    {
        readonly uint zid;
        string fname;      //initializing the variables
        string lname;
        string major;
        public enum academic_year { Freshman, Sophomore, Junior, Senior, PostBacc };
        float gpa;
        ushort hrs_enrolled;
        int accYear;

        public uint ZID { get { return zid; } }
        
        public string FNAME { get { return fname; } set { fname = value; } }
        public string LNAME { get { return lname; } set { lname = value; } }
        public string MAJOR { get { return major; } set { major = value; } }
        public int ACCYEAR { get { return accYear; } set { accYear = value; } }
        public float GPA { get { return gpa; } 
            set {
                if (value < 0 || value > 4)
                    throw new Exception("Error! GPA cannot be negative and more than 4.0");
                    gpa = value; 
                } }
        public ushort HRSENROLLED { get { return hrs_enrolled; } set { hrs_enrolled = value; } }

        public Student()    //default constructor
        {
            fname = null;
            lname = null;
            major = null;
            accYear = 0;
            gpa = 0;
            hrs_enrolled = 0;
        }

        public Student(uint p_zid, string p_fname, string p_lname, string p_major, int p_accyear, float p_gpa)  //alternate constructor
        {
            if (p_zid < 1000000)
                throw new Exception("Error! Student ID cannot be less than 1000000");
            zid = p_zid;
            FNAME = p_fname;
            LNAME = p_lname;
            MAJOR = p_major;
            ACCYEAR = p_accyear;
            GPA = p_gpa;
            HRSENROLLED = 0;
        }
        public int CompareTo(object obj)
        {
            Student st = obj as Student;
            return this.ZID.CompareTo(st.ZID);            
        }

        public override string ToString()
        {
            return "Z" + ZID + " -- " + LNAME + "," + FNAME + " [" + (academic_year)accYear + "]" + " (" + MAJOR + ") " + "|" + GPA + "|";
        }

        public int Enroll(Course newCourse)
        {
            if (newCourse.NUMSTUDENTS + 1 > newCourse.MAXCAPACITY)     //if total number of students in a course exceeded the maximum capacity
                return 5;
            if (newCourse.ENROLLED.Contains(Int32.Parse(this.ZID.ToString())))    //if student isnt listed as already enrolled into this course
                return 10;
            if (HRSENROLLED + newCourse.CREDITHRS > 18)   //if student credit hours crossed 18
                return 15;

            newCourse.ENROLLED.Add(Int32.Parse(this.ZID.ToString()));
            HRSENROLLED += newCourse.CREDITHRS;
            return 0;
        }

        public int Drop(Course newCourse)   //method to drop student from a course
        {
            if (!newCourse.ENROLLED.Contains(Int32.Parse(this.ZID.ToString())))
                return 20;

            newCourse.ENROLLED.Remove(Int32.Parse(this.ZID.ToString()));
            HRSENROLLED -= newCourse.CREDITHRS;
            return 0;
        }    
    
    }
}
