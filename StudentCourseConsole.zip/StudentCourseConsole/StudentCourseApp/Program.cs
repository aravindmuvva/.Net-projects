﻿/* Name : Abhinav Chamallamudi and Aravind Muvva
 * ZID : Z1826541 and Z1835959
 * Course : CSCI 504
 * Assignment Number : 1
 * Purpose: A program to create classes Student and Course and develop the mentioned methods and create a menu to show the results.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SudentCourseApp
{
    class Program
    {
        public static List<Student> students = new List<Student>();   //create studentpool and coursepool
        public static List<Course> courses = new List<Course>();
        private static int ReadFiles()
        {
            try
            {
                string fileName = @"..\\..\\2188_a1_input01.txt";         //reading first file
                if (!File.Exists(fileName))
                    return -1;

                using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName))   //using streamreader to access the file
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] values = line.Split(',');
                        Student _student = new Student(uint.Parse(values[0]), values[1], values[2], values[3], int.Parse(values[4]), float.Parse(values[5]));
                        students.Add(_student);
                    }
                }

                string fileName2 = @"..\\..\\2188_a1_input02.txt";       //reading second file
                if (!File.Exists(fileName2))
                    return -2;

                using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName2))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] values = line.Split(',');
                        Course _course = new Course(values[0], uint.Parse(values[1]), values[2], ushort.Parse(values[3]), ushort.Parse(values[4]));
                        courses.Add(_course);
                    }
                }
                return 0;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return -99;
            }
        }

        private static int PrintMenu()     //Printing the menu
        {
            Console.WriteLine();
            Console.WriteLine("1. Print Student List (All)");
            Console.WriteLine("2. Print Student List (Major)");
            Console.WriteLine("3. Print Student List (Academic Year)");
            Console.WriteLine("4. Print Course List");
            Console.WriteLine("5. Print Course Roster");
            Console.WriteLine("6. Enroll Student");
            Console.WriteLine("7. Drop Student");
            Console.WriteLine("8. Quit");
            Console.WriteLine();
            Console.Write("Your Input: ");
            string result = Console.ReadLine();
            if (result.ToLower() == "q" || result.ToLower() == "quit" || result.ToLower() == "exit")
            {
                result = "8";
            }
            if(result.Trim().Length==0)
            {
                Console.WriteLine("No Input Provided. Please try again...");
                return -1;
            }
            if(result!="1" && result!="2" &&  result!="3" &&  result!="4" &&  result!="5" &&  result!="6" &&  result!="7" &&  result!="8")
            {
                Console.WriteLine("Error! Invalid Input. Please try again...");
                return -1;
            }
            return Convert.ToInt32(result.ToString());
        }
        static void Main(string[] args)
        {
            try     //using try and catch to see if the file is accessible or not
            {
                int x = ReadFiles();
                if (x == -99)
                    return;
                if (x == -1)
                {
                    Console.WriteLine("Error! Student's File cannot be found.");
                    return;
                }
                if (x == -2)
                {
                    Console.WriteLine("Error! Courses's File cannot be found.");
                    return;
                }

                int userInput = 0;
                do
                {
                    userInput = PrintMenu();
                    switch (userInput)     //asking for user input
                    {
                        case 1:
                            Console.WriteLine("1. Print Student List (All)");     //listing all the students
                            Console.WriteLine("========================================");
                            students.Sort();
                            foreach (Student st in students)
                            {
                                Console.WriteLine(st.ToString());
                            }
                            break;
                        case 2:
                            Console.WriteLine("2. Print Student List (Major)");    //listing students based on their major
                            Console.WriteLine("========================================");

                            Console.Write("Please Input Major: ");
                            string major = Console.ReadLine();
                            students.Sort();
                            int w = 0;
                            foreach (Student st in students)
                            {
                                if (st.MAJOR.ToLower().Equals(major.ToLower()))
                                {
                                    Console.WriteLine(st.ToString());
                                    w += 1;
                                }
                            }
                            if (w == 0)
                                Console.WriteLine("No student found for input Major.");
                            break;
                        case 3:
                            Console.WriteLine("3. Print Student List (Academic Year)");      //listing students based on their academic year
                            Console.WriteLine("========================================");
                            Console.Write("Please Input Academic Year: ");
                            string acyear = Console.ReadLine();

                            if (acyear.Length == 0)
                                break;

                            students.Sort();
                            int z = 0, y = 0;
                            if (!Int32.TryParse(acyear, out z))
                            {
                                Student.academic_year enumValue = (Student.academic_year)Enum.Parse(typeof(Student.academic_year), acyear,true);
                                y = Array.IndexOf(Enum.GetValues(enumValue.GetType()), enumValue);
                            }
                            else
                                y = Int32.Parse(acyear);

                            foreach (Student st in students)
                            {
                                if (st.ACCYEAR.Equals(y))
                                    Console.WriteLine(st.ToString());
                            }
                            break;
                        case 4:
                            Console.WriteLine("4. Print Course List");     //printing the course list
                            Console.WriteLine("========================================");
                            courses.Sort();
                            foreach (Course cs in courses)
                            {
                                Console.WriteLine(cs.ToString());
                            }
                            break;
                        case 5:
                            Console.WriteLine("5. Print Course Roster");    //printing the course roster
                            Console.WriteLine("========================================");

                            Console.Write("Please Input Dept: ");
                            string dept = Console.ReadLine();
                            Console.Write("Please Input Course Num: ");
                            string cnum = Console.ReadLine();
                            Console.Write("Please Input Section Num: ");
                            string snum = Console.ReadLine();

                            Course cs4 = courses.Find(item => item.DEPTCODE.ToString() == dept && item.COURSENUM.ToString() == cnum && item.SECTIONNUM.ToString() == snum);
                            if (cs4 == null)
                            {
                                Console.WriteLine("Error! Dept/Course Num/Section Num doesn't exists.");
                                break;
                            }
                            cs4.PrintRoster();
                            break;
                        case 6:
                            Console.WriteLine("6. Enroll Student");     //enrolling student into a course
                            Console.WriteLine("========================================");

                            Console.Write("Please Input Student ID: ");
                            string zid = Console.ReadLine();
                            Student st2 = students.Find(item => item.ZID.ToString() == zid);
                            if (st2 == null)
                            {
                                Console.WriteLine("Error! Student ID doesn't exists.");
                                break;
                            }

                            Console.Write("Please Input Dept: ");
                            string dept2 = Console.ReadLine();
                            Console.Write("Please Input Course Num: ");
                            string cnum2 = Console.ReadLine();
                            Console.Write("Please Input Section Num: ");
                            string snum2 = Console.ReadLine();



                            Course cs2 = courses.Find(item => item.DEPTCODE.ToString() == dept2 && item.COURSENUM.ToString() == cnum2 && item.SECTIONNUM.ToString() == snum2);
                            if (cs2 == null)
                            {
                                Console.WriteLine("Error! Dept/Course Num/Section Num doesn't exists.");
                                break;
                            }

                            int temp = st2.Enroll(cs2);
                            switch (temp)
                            {
                                case 0:
                                    cs2.NUMSTUDENTS += 1;
                                    Console.WriteLine("***Student Enrolled***");
                                    break;
                                case 5:
                                    Console.WriteLine("Error! Course exceeding maximum capacity.");
                                    break;
                                case 10:
                                    Console.WriteLine("Error! Student already enrolled.");
                                    break;
                                case 15:
                                    Console.WriteLine("Error! Student's total credit hours will exceed 18.");
                                    break;
                            }
                            break;
                        case 7:
                            Console.WriteLine("7. Drop Student");    //dropping student from a particular course if exists or showing that student didnt is not in the course to drop
                            Console.WriteLine("========================================");

                            Console.Write("Please Input Student ID: ");
                            string zid2 = Console.ReadLine();
                            Student st3 = students.Find(item => item.ZID.ToString() == zid2);
                            if (st3 == null)
                            {
                                Console.WriteLine("Error! Student ID doesn't exists.");
                                break;
                            }

                            Console.Write("Please Input Dept: ");
                            string dept3 = Console.ReadLine();
                            Console.Write("Please Input Course Num: ");
                            string cnum3 = Console.ReadLine();
                            Console.Write("Please Input Section Num: ");
                            string snum3 = Console.ReadLine();

                            Course cs3 = courses.Find(item => item.DEPTCODE.ToString() == dept3 && item.COURSENUM.ToString() == cnum3 && item.SECTIONNUM.ToString() == snum3);
                            if (cs3 == null)
                            {
                                Console.WriteLine("Error! Dept/Course Num/Section Num doesn't exists.");
                                break;
                            }

                            int temp2 = st3.Drop(cs3);
                            switch (temp2)
                            {
                                case 0:
                                    cs3.NUMSTUDENTS -= 1;
                                    Console.WriteLine("***Student Dropped***");
                                    break;
                                case 20:
                                    Console.WriteLine("Error! Student not enrolled.");
                                    break;
                            }
                            break;
                    }
                }
                while (userInput != 8);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
